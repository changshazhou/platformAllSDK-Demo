"use strict";
cc._RF.push(module, 'e1b90/rohdEk4SdmmEZANaD', 'Helloworld');
// Script/Helloworld.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Helloworld = /** @class */ (function (_super) {
    __extends(Helloworld, _super);
    function Helloworld() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.label = null;
        _this.text = 'hello';
        _this.videoPath = "";
        return _this;
    }
    Helloworld.prototype.start = function () {
        // init logic
        this.label.string = this.text;
        moosnow.http.getAllConfig(function (res) {
            console.log('所有配置', res);
        });
        moosnow.form.loadAd({
            floatPositon: [{
                    x: -496.015,
                    y: -128
                }, {
                    x: -183.045,
                    y: 24
                }, {
                    x: 434.285,
                    y: 123
                }, {
                    x: 592,
                    y: 7
                }],
            hideForm: true,
            callback: function () {
                // moosnow.form.showAd(moosnow.AD_POSITION.BANNER | moosnow.AD_POSITION.FLOAT | moosnow.AD_POSITION.EXPORT_FIXED, () => {
                // })
                // moosnow.form.showAd(moosnow.AD_POSITION.MASK | moosnow.AD_POSITION.WAIT | moosnow.AD_POSITION.EXPORT_FIXED, () => {
                // })
                // moosnow.form.showAd(moosnow.AD_POSITION.BACK | moosnow.AD_POSITION.WAIT | moosnow.AD_POSITION.EXPORT, () => {
                //     console.log('点击了返回按钮')
                //     moosnow.form.showAd(moosnow.AD_POSITION.FLOAT | moosnow.AD_POSITION.BANNER, () => {
                //         console.log('点击了返回按钮')
                //     })
                // })
            }
        });
        // // moosnow.form.showAd(moosnow.AD_POSITION.BANNER|moosnow.AD_POSITION.FLOAT,)
        // moosnow.event.addListener(moosnow.PLATFORM_EVENT.ON_BANNER_ERROR, this, () => {
        //     console.log('moosnow.PLATFORM_EVENT.ON_BANNER_ERROR')
        // })
        // moosnow.event.sendEventImmediately(moosnow.PLATFORM_EVENT.ON_BANNER_ERROR, null);
        // // if (moosnow.APP_PLATFORM.WX == moosnow.getAppPlatform() && window["wx"])
        // //     cc.loader.downloader.loadSubpackage('tex', (err) => {
        // //         if (err) {
        // //             return console.error(err);
        // //         }
        // //     });
        // moosnow.event.addListener(moosnow.PLATFORM_EVENT.ON_PLATFORM_HIDE, this, (res) => {
        //     console.log('平台隐藏时', res)
        // })
        // moosnow.event.addListener(moosnow.PLATFORM_EVENT.ON_PLATFORM_SHOW, this, (res) => {
        //     console.log('平台显示时', res)
        // })
        // moosnow.platform.createGameRecorderShareButton(
        //     'https://liteplay-1253992229.cos.ap-guangzhou.myqcloud.com/SDK/guide/guide_error2.png',
        //     'https://liteplay-1253992229.cos.ap-guangzhou.myqcloud.com/SDK/guide/guide_error2.png',
        //     {},
        //     () => {
        //     }
        // );
    };
    Helloworld.prototype.showToast = function () {
        moosnow.form.showToast("这是一个Toast消息");
    };
    Helloworld.prototype.testHttp = function () {
        moosnow.http.request('https://cdn.liteplay.com.cn/config/wxeb720d78f75a425f.json', {}, 'GET', function (res) {
            console.log('testHttp success ', res);
        }, function (res) {
            console.log('testHttp error ', res);
        });
    };
    Helloworld.prototype.showMistouch = function () {
        moosnow.form.showMistouch({
            hideForm: true,
            url: "",
            coinNum: 500,
            callback: function () {
                console.log('callback');
            }
        });
    };
    Helloworld.prototype.showCoin = function () {
        var options = new moosnow.showOptions.coinOptions();
        options.coinNum = 500;
        options.callback = function () {
            console.log('金币动画完成');
        };
        moosnow.form.showCoin(options);
    };
    Helloworld.prototype.showShare = function () {
        moosnow.form.showShare({
            hideForm: true,
            shareCoinNum: 500,
            shareCallback: function (res) {
                console.log('shareCallback', res);
            },
            callback: function () {
                console.log('callback');
            }
        });
    };
    Helloworld.prototype.showPrize = function () {
        moosnow.form.showPrize({
            hideForm: true,
            logo: ""
        });
    };
    Helloworld.prototype.showPrize2 = function () {
    };
    Helloworld.prototype.showAd4 = function () {
        moosnow.form.showAd(moosnow.AD_POSITION.ROTATE | moosnow.AD_POSITION.WAIT | moosnow.AD_POSITION.BACK | moosnow.AD_POSITION.MASK, function () {
            moosnow.form.showAd(moosnow.AD_POSITION.TOP, function () { });
        });
    };
    Helloworld.prototype.showAd3 = function () {
        moosnow.form.showAd(moosnow.AD_POSITION.EXPORT_FIXED | moosnow.AD_POSITION.MASK | moosnow.AD_POSITION.WAIT | moosnow.AD_POSITION.BACK, function () {
            moosnow.form.showAd(moosnow.AD_POSITION.BANNER | moosnow.AD_POSITION.FLOAT | moosnow.AD_POSITION.SIDE, function () {
            });
        });
    };
    Helloworld.prototype.showAd2 = function () {
        moosnow.form.showAd(moosnow.AD_POSITION.LEFTRIGHT, function () {
            moosnow.form.showAd(moosnow.AD_POSITION.BANNER | moosnow.AD_POSITION.FLOAT | moosnow.AD_POSITION.SIDE, function () {
            });
        });
    };
    Helloworld.prototype.showAd = function () {
        moosnow.form.showAd(moosnow.AD_POSITION.EXPORT | moosnow.AD_POSITION.MASK | moosnow.AD_POSITION.WAIT | moosnow.AD_POSITION.BACK, function () {
            moosnow.form.showAd(moosnow.AD_POSITION.BANNER | moosnow.AD_POSITION.FLOAT | moosnow.AD_POSITION.SIDE, function () {
            });
        });
    };
    Helloworld.prototype.showTotal = function () {
        moosnow.form.showTotal({
            coinNum: 500,
            hideForm: true,
            videoText: "5倍视频领取",
            callback: function () {
                console.log('点继续游戏');
            },
            videoCallback: function () {
                console.log('看完视频后点继续游戏');
            }
        });
    };
    Helloworld.prototype.showRespawn = function () {
    };
    Helloworld.prototype.hideAd = function () {
        moosnow.form.showAd(moosnow.AD_POSITION.NONE, null);
    };
    Helloworld.prototype.showVideo = function () {
        moosnow.platform.showVideo(function (res) {
            switch (res) {
                case moosnow.VIDEO_STATUS.NOTEND:
                    console.log('视频未观看完成 ');
                    break;
                case moosnow.VIDEO_STATUS.ERR:
                    console.log('获取视频错误 ');
                    break;
                case moosnow.VIDEO_STATUS.END:
                    console.log('观看视频结束 ');
                default:
                    break;
            }
        });
    };
    Helloworld.prototype.showBanner = function () {
        moosnow.platform.showBanner();
    };
    Helloworld.prototype.showBottomBanner = function () {
        moosnow.platform.showBanner(false, function () { }, moosnow.BANNER_POSITION.BOTTOM);
    };
    Helloworld.prototype.showCenterBanner = function () {
        moosnow.platform.showBanner(false, function () { }, moosnow.BANNER_POSITION.CENTER);
    };
    Helloworld.prototype.showTopBanner = function () {
        moosnow.platform.showBanner(false, function () { }, moosnow.BANNER_POSITION.TOP);
    };
    Helloworld.prototype.showAutoBanner = function () {
        moosnow.platform.showAutoBanner();
    };
    Helloworld.prototype.showIntervalBanner = function () {
        moosnow.platform.showIntervalBanner();
    };
    Helloworld.prototype.hideBanner = function () {
        moosnow.platform.hideBanner();
        moosnow.platform.clearIntervalBanner();
    };
    Helloworld.prototype.showBox = function () {
        moosnow.platform.showAppBox(function () {
            console.log('关闭盒子');
        });
    };
    Helloworld.prototype.showNativeBanner = function () {
        // console.log('moosnow.platform.moosnowConfig.bannerId', moosnow.platform.moosnowConfig.bannerId)
        // const bannerAd = qq.createBannerAd({
        //     adUnitId: '393fd2c197f4fdda1f9729ef36737890',
        //     style: {
        //         top: 0,
        //         width: 320,
        //         height: 100,
        //         left: 0
        //     }
        // })
        // // 尺寸调整时会触发回调         
        // // 注意：如果在回调里再次调整尺寸，要确保不要触发死循环！！！    
        // bannerAd.onResize(size => {
        //     console.log('Resize后正式宽高:', size.width, size.height);
        //     // 在这里可以根据banner宽高进行定位        
        //     // bannerAd.style.top = 76;
        //     // bannerAd.style.left = 320;
        // });
        // bannerAd.onError(res => { console.log('bannerAd onError', res) })
        // bannerAd.onLoad(res => {
        //     console.log('bannerAd onLoad', res)
        //     bannerAd.show().then(() => {
        //         console.log('bannerAd show ok')
        //     }).catch((res) => {
        //         console.log('bannerAd show error', res)
        //     });
        // })
    };
    Helloworld.prototype.startRecord = function () {
        moosnow.platform.startRecord();
    };
    Helloworld.prototype.stopRecord = function () {
        var _this = this;
        if (moosnow.getAppPlatform() == moosnow.APP_PLATFORM.BYTEDANCE)
            moosnow.platform.stopRecord(function (res) {
                if (res.videoPath) {
                    _this.videoPath = res.videoPath;
                }
            });
        else {
            moosnow.platform.stopRecord(function (res) {
                // left = 10 表示居左10像素 类似 banner 中的left 
                moosnow.platform.showShareButton({
                    left: 0,
                    top: 0
                });
            });
        }
    };
    Helloworld.prototype.shareRecord = function () {
        moosnow.platform.share({
            channel: moosnow.SHARE_CHANNEL.VIDEO
        }, function (res) {
            console.log('分享结束', res);
        }, function (err) {
            console.log('视频太短', err);
        });
    };
    Helloworld.prototype.hideShareButton = function () {
        moosnow.platform.hideShareButton();
    };
    Helloworld.prototype.showInter = function () {
        moosnow.platform.showInter();
    };
    Helloworld.prototype.navigate2Mini = function () {
        // let row = {
        //     appid: "30238187",
        //     atlas: "",
        //     boxAppid: "",
        //     desc: "",
        //     img: "https://txcdn.ylll111.xyz/more_channel/6fb282c9ba4a7f6859f6d26c70335c58.png",
        //     path: "",
        //     pkgName: "com.cszs.qscssd.nearme.gamecenter",
        //     title: "枪神传说3D",
        // }
        // moosnow.platform.navigate2Mini(row, () => {
        // }, () => {
        // }, () => {
        // })
    };
    Helloworld.prototype.showTry = function () {
        moosnow.form.showTry({
            skinUrl: "https://liteplay-1253992229.cos.ap-guangzhou.myqcloud.com/Game/demo/tryForm/7.png",
            hideForm: true,
            callback: function () {
                console.log('点继续游戏');
            },
            videoCallback: function () {
                console.log('看完视频后点继续游戏');
            }
        });
    };
    Helloworld.prototype.showEnd = function () {
        moosnow.form.showEnd({
            hideForm: true,
            callback: function () {
                console.log('点击了确认');
            }
        });
    };
    Helloworld.prototype.showPause = function () {
        moosnow.form.showPause({
            hideForm: true,
            callback: function () {
                console.log('点击了确认');
            }
        });
    };
    Helloworld.prototype.showSet = function () {
        moosnow.form.showSet({
            hideForm: true,
            vibrateCallback: function () {
                console.log('vibrateCallback');
            },
            musicCallback: function () {
                console.log('musicCallback');
            }
        });
    };
    Helloworld.prototype.showEgg = function () {
        moosnow.form.showBox({
            rowNum: 3,
            colNum: 3,
            coinNum: [100, 300],
            videoCoinNum: [100, 300],
            videoNum: [1, 5, 7],
            openCallback: function (num) {
                console.log('openCallback', num);
            },
            callback: function () {
                console.log('callback');
            },
            hideForm: true
        });
    };
    Helloworld.prototype.showNative = function () {
        moosnow.form.showNativeAd({
            x: 0, y: 0,
            hideForm: true,
            callback: function () {
            },
            nullCallback: function () {
            }
        });
    };
    __decorate([
        property(cc.Label)
    ], Helloworld.prototype, "label", void 0);
    __decorate([
        property
    ], Helloworld.prototype, "text", void 0);
    Helloworld = __decorate([
        ccclass
    ], Helloworld);
    return Helloworld;
}(cc.Component));
exports.default = Helloworld;

cc._RF.pop();