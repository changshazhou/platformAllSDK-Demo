import CocosBaseForm from "../form/CocosBaseForm";
export default class CocosBaseComponent extends CocosBaseForm {
}
