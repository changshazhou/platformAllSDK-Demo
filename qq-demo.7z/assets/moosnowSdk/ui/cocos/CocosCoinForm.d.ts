import CoinForm from "../engine/CoinForm";
export default class CocosCoinForm extends CoinForm {
    get rootNode(): cc.Node;
    flyAnim(logic: any, endVec: any, callback: any): void;
}
