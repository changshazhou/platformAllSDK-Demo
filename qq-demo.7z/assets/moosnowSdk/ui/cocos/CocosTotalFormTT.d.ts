import TotalFormTT from "../engine/TotalFormTT";
export default class CocosTotalFormTT extends TotalFormTT {
    addEvent(): void;
    removeEvent(): void;
    changeUI(): void;
}
