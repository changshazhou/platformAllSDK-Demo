import shareFormTT from "../engine/shareFormTT";
export default class CocosShareFormTT extends shareFormTT {
    addListener(): void;
    removeListener(): void;
}
