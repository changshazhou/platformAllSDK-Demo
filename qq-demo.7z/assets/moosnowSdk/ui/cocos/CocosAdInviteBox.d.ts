import AdInviteBox from "./template/CocosInviteBox";
export default class CocosAdInviteBox extends AdInviteBox {
    addListener(): void;
    removeListener(): void;
    initBox(userName: any, logo: any, gameName: any): void;
}
