import NodeAttribute from "./NodeAttribute";
export default class ScrollAttribute extends NodeAttribute {
    horizontal: boolean;
    vertical: boolean;
}
