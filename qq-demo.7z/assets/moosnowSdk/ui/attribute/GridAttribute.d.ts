export default class GridAttribute {
    left: number;
    top: number;
    right: number;
    bottom: number;
}
