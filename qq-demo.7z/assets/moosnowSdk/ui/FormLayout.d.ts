export default class FormLayout {
    static readonly ToastForm: string;
    static readonly AdForm: string;
    static readonly MistouchForm: string;
    static readonly PrizeForm: string;
    static readonly TotalForm: string;
    static readonly EndForm: string;
    static readonly RespawnForm: string;
    static readonly FailForm: string;
    static readonly PauseForm: string;
    static readonly ShareForm: string;
    static readonly TryForm: string;
    static readonly SetForm: string;
    static readonly BoxForm: string;
    static readonly NativeForm: string;
}
