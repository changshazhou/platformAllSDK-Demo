import BaseForm from "./BaseForm";
export default class NodeEvent extends BaseForm {
    static get TOUCH_START(): string;
    static get TOUCH_END(): string;
}
