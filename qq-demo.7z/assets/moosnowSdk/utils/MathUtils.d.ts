export default class MathUtils {
    static randomNumBoth(Min: any, Max: any): any;
    /**
    * 传入概率值数组，返回中标的概率下标
    * @param parr 概率数组
    */
    static probabilitys(parr: any): any;
}
