export default class vectory {
    x: number;
    y: number;
    z?: number;
}
