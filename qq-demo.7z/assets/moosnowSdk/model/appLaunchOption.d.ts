/**
 * banner位置
 */
export default class appLaunchOption {
    appId: string;
    query: string;
    extraData: Object;
}
