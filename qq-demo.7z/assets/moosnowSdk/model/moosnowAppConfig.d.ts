/**
 * 广告结果
 */
export default class moosnowAppConfig {
    bannerId: string;
    videoId: string;
    interId: string;
    boxId: string;
    nativeId: Array<string>;
    moosnowAppId: string;
    version: string;
    url: string;
}
