import showOptions from "./showOptions";
/**
 * 皮肤试用
 */
export default class showSetOptions extends showOptions {
    /**
     * 不试用 回调
     */
    vibrateCallback?: Function;
    /**
     * 视频回调
     */
    musicCallback?: Function;
}
