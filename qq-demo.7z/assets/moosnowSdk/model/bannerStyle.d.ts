/**
 * banner位置
 */
export default class bannerStyle {
    top: number;
    left: number;
    width: number;
    height: number;
}
