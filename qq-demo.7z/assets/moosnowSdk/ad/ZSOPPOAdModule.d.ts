import AdModule from "./AdModule";
export default class ZSOPPOAdModule extends AdModule {
    getRemoteAd(cb: Function): void;
}
