import AdModule from "./AdModule";
export default class WXAdModule extends AdModule {
    getRemoteAd(cb: any): void;
    private repairAd;
}
