import AdModule from "./AdModule";
export default class OPPOAdModule extends AdModule {
    getRemoteAd(cb: any): void;
}
