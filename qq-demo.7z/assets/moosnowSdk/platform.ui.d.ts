import { BaseUIModule } from "./ui/engine/BaseUIModule";
import BaseEntityModule from "./ui/engine/BaseEntityModule";
import LogicControl from "./ui/LogicControl";
import UIForm from "./ui/UIForm";
import Delay from "./framework/Delay";
import showEndOptions from "./model/showEndOptions";
import showPrizeOptions from "./model/showPrizeOptions";
import showShareOptions from "./model/showShareOptions";
import showTotalOptions from "./model/showTotalOptions";
import showTouchOptions from "./model/showTouchOptions";
import showCoinOptions from "./model/showCoinOptions";
import UIFormSetting from "./config/UIFormSetting";
export default class moosnowUI {
    showOptions: {
        endOptions: typeof showEndOptions;
        prizeOptions: typeof showPrizeOptions;
        shareOptions: typeof showShareOptions;
        totalOptions: typeof showTotalOptions;
        touchOptions: typeof showTouchOptions;
        coinOptions: typeof showCoinOptions;
    };

    static formSetting: typeof UIFormSetting;
    static ui: BaseUIModule;
    /**
     * form UI 操作
     */
    static form: UIForm;
    /**
     * form表单控制
     */
    static control: LogicControl;
    static entity: BaseEntityModule;
    static delay: Delay;
}
