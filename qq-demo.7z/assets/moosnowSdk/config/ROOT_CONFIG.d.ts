export declare const ROOT_CONFIG: {
    UI_ROOT: string;
    ENTITY_ROOT: string;
    HTTP_ROOT: string;
};
