export declare const EntitysName: {
    INVITE_BOX: string;
    COIN: string;
};
