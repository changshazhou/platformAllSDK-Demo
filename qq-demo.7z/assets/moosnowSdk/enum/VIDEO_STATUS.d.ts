export declare const VIDEO_STATUS: {
    END: string;
    NOTEND: string;
    ERR: string;
};
