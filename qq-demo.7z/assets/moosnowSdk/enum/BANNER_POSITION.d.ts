export declare const BANNER_POSITION: {
    TOP: string;
    CENTER: string;
    BOTTOM: string;
    CUSTOM: string;
};
