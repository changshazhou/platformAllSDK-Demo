export declare const ENGINE_TYPE: {
    COCOS: string;
    LAYA: string;
    NONE: string;
};
