export declare enum MISTOUCH_BANNER_TYPE {
    AUTO_HIDE = 1,
    MAST = 2
}
