export declare const SHARE_MSG: {
    FAIL: string;
};
