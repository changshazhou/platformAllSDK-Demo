export declare const SHARE_CHANNEL: {
    ARTICLE: string;
    VIDEO: string;
    TOKEN: string;
    LINK: string;
};
