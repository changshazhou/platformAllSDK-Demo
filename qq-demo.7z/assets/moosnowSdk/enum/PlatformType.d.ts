export declare enum PlatformType {
    /**
     * 微信
     */
    WX = 0,
    /**
     * 字节跳动
     */
    BYTEDANCE = 1,
    /**
     * OPPO
     */
    OPPO = 2,
    /**
     * OPPO
     */
    OPPO_ZS = 3,
    /**
     * 百度
     */
    BAIDU = 4,
    /**
     * QQ
     */
    QQ = 5,
    /**
     * PC电脑
     */
    PC = 6,
    /**
     * VIVO
     */
    VIVO = 7
}
