export declare const VIDEO_MSG: {
    ERR: string;
    NOTEND: string;
};
